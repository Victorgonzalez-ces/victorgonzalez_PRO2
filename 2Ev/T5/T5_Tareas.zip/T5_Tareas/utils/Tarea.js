class Tarea{
    id;
    titulo;
    descripcion;
    prioridad;
    prioritaria;
    fecha;

    constructor(id, titulo, descripcion, prioridad, prioritaria, fecha){
        this.id = id;
        this.descripcion = descripcion;
        this.titulo = titulo;
        this.prioridad = prioridad;
        this.prioritaria = prioritaria;
        this.fecha = fecha;
    }
}